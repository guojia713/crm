import { Prestation } from './prestation';

describe('Prestation', () => {
  it('should create an instance', () => {
    expect(new Prestation()).toBeTruthy();
  });
});
