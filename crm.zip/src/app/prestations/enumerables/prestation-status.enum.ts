export enum PrestationStatus {
  OPTION = 'Option',
  ANNULE = 'Annulé',
  COMFIRME = 'Confirmé',
  FACTURE = 'Facturé'
}
