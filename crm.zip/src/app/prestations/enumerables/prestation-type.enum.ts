export enum PrestationType {
  PRESTATION = 'Prestation',
  FORMATION = 'Formation'
}
