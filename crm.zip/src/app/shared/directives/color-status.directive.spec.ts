import { ColorStatusDirective } from './color-status.directive';

describe('ColorStatusDirective', () => {
  it('should create an instance', () => {
    const directive = new ColorStatusDirective();
    expect(directive).toBeTruthy();
  });
});
