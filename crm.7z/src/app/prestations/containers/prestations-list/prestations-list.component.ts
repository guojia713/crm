import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prestations-list',
  templateUrl: './prestations-list.component.html',
  styleUrls: ['./prestations-list.component.scss']
})
export class PrestationsListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
